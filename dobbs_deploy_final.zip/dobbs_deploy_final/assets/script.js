const smsNumber = '+13143656272';
const displayNumber = '(314) 365-6272';
const keyword = 'DOBBS';

const applyForm = document.getElementById('applyForm');
const resultCard = document.getElementById('resultCard');
const messagePreview = document.getElementById('messagePreview');
const openSmsBtn = document.getElementById('openSmsBtn');
const copyMessageBtn = document.getElementById('copyMessageBtn');
const copyNumberBtn = document.getElementById('copyNumberBtn');
const copyKeywordBtn = document.getElementById('copyKeywordBtn');
const copyNumberFromFormBtn = document.getElementById('copyNumberFromFormBtn');
const copyStatus = document.getElementById('copyStatus');
const formStatus = document.getElementById('formStatus');
const deviceBadge = document.getElementById('deviceBadge');

function isMobileLike() {
  return /Android|iPhone|iPad|iPod/i.test(navigator.userAgent) || window.innerWidth < 768;
}

function buildSmsLink(message) {
  return `sms:${smsNumber}?body=${encodeURIComponent(message)}`;
}

function buildMessage() {
  const name = document.getElementById('fullName').value.trim();
  const phone = document.getElementById('phone').value.trim();
  const role = document.getElementById('role').value;
  const city = document.getElementById('city').value.trim();
  const experience = document.getElementById('experience').value;
  return `Hi Dobbs, my name is ${name}. My phone is ${phone}. I'm interested in the ${role} role near ${city}. Experience: ${experience}. Keyword: ${keyword}`;
}

async function copyText(text, target, successMessage) {
  try {
    await navigator.clipboard.writeText(text);
    target.textContent = successMessage;
  } catch (err) {
    target.textContent = `Copy failed. Please manually copy: ${text}`;
  }
}

applyForm.addEventListener('submit', (e) => {
  e.preventDefault();
  if (!applyForm.reportValidity()) return;
  const message = buildMessage();
  const smsLink = buildSmsLink(message);
  messagePreview.value = message;
  openSmsBtn.href = smsLink;
  resultCard.classList.remove('hidden');
  deviceBadge.textContent = isMobileLike() ? 'Mobile' : 'Desktop';
  formStatus.textContent = isMobileLike()
    ? 'Opening your text app also works on this device.'
    : `On desktop, copy the message and send it to ${displayNumber}.`;
  resultCard.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  if (isMobileLike()) {
    setTimeout(() => { window.location.href = smsLink; }, 150);
  }
});

copyMessageBtn.addEventListener('click', () => copyText(messagePreview.value, formStatus, 'Message copied. Paste it into a text to (314) 365-6272.'));
copyNumberBtn.addEventListener('click', () => copyText(displayNumber, copyStatus, 'Number copied.'));
copyKeywordBtn.addEventListener('click', () => copyText(keyword, copyStatus, 'Keyword copied.'));
copyNumberFromFormBtn.addEventListener('click', () => copyText(displayNumber, formStatus, 'Number copied.'));

document.querySelectorAll('[data-sms-link]').forEach((link) => {
  link.addEventListener('click', (e) => {
    if (!isMobileLike()) {
      e.preventDefault();
      copyText(`${displayNumber} — text ${keyword}`, copyStatus, 'Number and keyword copied for desktop use.');
      alert(`Text ${keyword} to ${displayNumber}`);
    }
  });
});

const params = new URLSearchParams(window.location.search);
if (params.get('role')) document.getElementById('role').value = params.get('role');
if (params.get('city')) document.getElementById('city').value = params.get('city');
