Upload index.html and the assets folder to your host. If using Netlify, drag the whole dobbs_deploy_final folder in. Update your SMS provider to route keyword DOBBS on +1 314-365-6272.
